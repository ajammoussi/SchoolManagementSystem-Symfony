create definer = root@localhost trigger trg_student_after_insert
    after insert
    on student
    for each row
BEGIN
    INSERT INTO user (email, roles, password) VALUES (NEW.email, 'ROLE_STUDENT', NEW.password);
END;

