create definer = root@localhost view user_auth as
select `insatplatform_symfony`.`student`.`id`                                                                   AS `id`,
       `insatplatform_symfony`.`student`.`email`                                                                AS `email`,
       `insatplatform_symfony`.`student`.`password`                                                             AS `password`,
       'ROLE_STUDENT'                                                                                           AS `type`,
       concat(`insatplatform_symfony`.`student`.`firstname`, ' ',
              `insatplatform_symfony`.`student`.`lastname`)                                                     AS `username`
from `insatplatform_symfony`.`student`
union all
select `insatplatform_symfony`.`id`                                                         AS `id`,
       `insatplatform_symfony`.`email`                                                      AS `email`,
       `insatplatform_symfony`.`password`                                                   AS `password`,
       'ROLE_TEACHER'                                                                       AS `type`,
       concat(`insatplatform_symfony`.`firstname`, ' ', `insatplatform_symfony`.`lastname`) AS `username`
from `insatplatform_symfony`.`teacher` `insatplatform_symfony`
union all
select `insatplatform_symfony`.`admin`.`id`       AS `id`,
       `insatplatform_symfony`.`admin`.`email`    AS `email`,
       `insatplatform_symfony`.`admin`.`password` AS `password`,
       'ROLE_ADMIN'                               AS `type`,
       `insatplatform_symfony`.`admin`.`username` AS `username`
from `insatplatform_symfony`.`admin`;

