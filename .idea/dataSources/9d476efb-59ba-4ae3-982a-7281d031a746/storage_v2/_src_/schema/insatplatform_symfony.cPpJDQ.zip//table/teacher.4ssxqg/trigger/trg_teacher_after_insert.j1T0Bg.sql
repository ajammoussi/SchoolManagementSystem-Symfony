create definer = root@localhost trigger trg_teacher_after_insert
    after insert
    on teacher
    for each row
BEGIN
    INSERT INTO user (email, roles, password) VALUES (NEW.email, 'ROLE_TEACHER', NEW.password);
END;

